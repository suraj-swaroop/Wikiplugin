import pandas as pd
import re
import ast

def generateDrilldownResult(description):
	dict = {}
	return dict


def get_drilldown_result(content):
	# input will be link or title (string) 

	#result = generateDrilldownResult(content)
	result = {
		'c_title': ['wikipedia', 'asdfawe', '13rqef3'],
		'c_link': ['https://en.wikipedia.org/wiki/Main_Page', 'dsfasfsd222', 'wjfwae333'],
		'c_score': [0.42, 0.842, 0.351],
		's_title': ['wikipedia', 'asdfawe', '13rqef3'],
		's_link': ['https://en.wikipedia.org/wiki/Main_Page', 'dsfasfsd222', 'wjfwae333'],
		's_score': [0.42, 0.842, 0.351]
	}

	return result

