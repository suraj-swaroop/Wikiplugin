import pandas as pd
import re
import ast

#from web_application_2 import stop_words, documents_web, instance_web, preprocess
#from web_application_2 import documents_blog, instance_blog

def generatePriorityResult(description):
	df = similarityBlog(description)
	dict = {}
	try:
		aBC = [df.iloc[0]['BackColor'], df.iloc[1]['BackColor'], df.iloc[2]['BackColor'], df.iloc[3]['BackColor']]
		aLC = [df.iloc[0]['LinkColor'], df.iloc[1]['LinkColor'], df.iloc[2]['LinkColor'], df.iloc[3]['LinkColor']]
		aTC = [df.iloc[0]['TextColor'], df.iloc[1]['TextColor'], df.iloc[2]['TextColor'], df.iloc[3]['TextColor']]
		aTF = [df.iloc[0]['TitleFont'], df.iloc[1]['TitleFont'], df.iloc[2]['TitleFont'], df.iloc[3]['TitleFont']]
		aBF = [df.iloc[0]['BodyFont'], df.iloc[1]['BodyFont'], df.iloc[2]['BodyFont'], df.iloc[3]['BodyFont']]
	except:
		aBC = [df.iloc[0]['BackColor']]
		aLC = [df.iloc[0]['LinkColor']]
		aTC = [df.iloc[0]['TextColor']]
		aTF = [df.iloc[0]['TitleFont']]
		aBF = [df.iloc[0]['BodyFont']]

	dict['total'] = len(aBC)
	dict['back_color'] = aBC
	dict['link_color'] = aLC
	dict['text_color'] = aTC
	dict['title_font'] = aTF
	dict['body_font'] = aBF
	return dict


def get_priority_result():

	# load cached blog_model
	# transformed = blog_model.transform(content)

	# get dict of lists of top 3 recommending styles for each attribute
	# below is a sample result variable that I will use to build flask application

	#result = generatePriorityResult(content)
	result = ['art1', 'art2', 'art3', 'art4', 'art5']

	# result = {'back_color': ['#FAFAFA', '#ec5868', '#847d81', '#FAFAFA'],
 # 'link_color': ['#529ECC', '#fce7aa', '#03131d', '#529ECC'],
 # 'text_color': ['#444444', '#fce7aa', '#444444', '#444444'],
 # 'title_font': ['Gibson', 'SimHei', 'Georgia', 'Gibson'],
 # 'body_font': ['Helvetica Neue',
 #  'Helvetica Neue',
 #  'Helvetica Neue',
 #  'Helvetica Neue']}

	return result

