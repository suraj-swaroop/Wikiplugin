import sqlalchemy
import wikipedia
import sys

def check_wiki(title):

    wikipedia.set_lang('en')

    try:
        wiki = wikipedia.page(titles[i])
        if wiki.title.lower().replace("-","").replace("_","") == titles[i].lower().replace("-","").replace("_",""):
            simple_list.append(wiki.title)
        else:
            no_simple_page.append(titles[i])

            url = 'https://en.wikipedia.org/wiki/'+titles[i]
            result['article'].append(titles[i])
            result['url'].append(url)
            result['difficulty'].append(diff[i])
            result['rtime'].append(rtime[i])

    except:
        no_simple_page.append(titles[i])
            



    check = wikipedia.page(title)

    check.title.replace(' ', '_')
    
    return df1_return.to_dict()

def check_db(title):

    with open('web_application/database.key', 'r') as file:
        DB_URIfix = file.read()
    engine = sqlalchemy.create_engine(DB_URIfix)


    return title

