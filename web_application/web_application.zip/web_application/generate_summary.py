import pandas as pd
import re
import ast

def generateSummaryResult(description):
	dict = {}
	return dict


def get_summary_result(content):
	# input will be "YYYYMMDD" (string) 

	#result = generateSummaryResult(content)
	result = {
		'topics': ['T1', 'T2', 'T3'],
		'article_count': [4569, 2918, 634],
		'proportion': [0.294, 0.191, 0.060],
		'date': content
	}

	return result

